
### Installation

- Install Python-3.10.13
- Install python dependencies using below command
```
pip install -r requirements.txt
```

### ENV
- Get required env file from developers currently listed in wiki


### Data
- Get required data from S3, use the below command in root directory of the repo
```
aws s3 sync s3://consultancy-ml/LLM-Applications/LAM/ ./
```

### together ai
- For changing models in together ai notebook, you can refer to, https://docs.together.ai/docs/inference-models

- For extracting data from ppt - extraction.ipynb

- For querying directly on generated json - together-ai-query.ipynb

- For querying using chromadb on genrated json - chroma.ipynb

### To Create Docker Image Locally 

```

./deployment/build.sh

```
