if [ -z "$1" ]; then
  echo "Usage: $0 <MODEL_SIZE>"
  exit 1
fi
MODEL_SIZE=$1
export IMAGE_NAME=test
docker build -t $IMAGE_NAME -f deployment/dockerfile . --progress=plain --build-arg MODEL_SIZE=$MODEL_SIZE
# docker run -p 4000:4000 $IMAGE_NAME