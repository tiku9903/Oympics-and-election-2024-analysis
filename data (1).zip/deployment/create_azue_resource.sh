export PROJECT_PREFIX=lamtroubleshootingcopilot
export PROJECT_PREFIX_DASH=lam-troubleshooting-copilot
export PROJECT_PREFIX_UNDERSCORE=lam_troubleshooting_copilot
export USER_EMAIL=swapnil.kunjir@cctech.co.in
export USER_NAME=SwapnilKunjir

export RESOURCE_GROUP=DT-LAM-LT
export LOCATION=westus3

if [ -z "$1" ]; then
  echo "Usage: $0 <MODEL_SIZE>"
  exit 1
fi
MODEL_SIZE=$1

az extension add --name containerapp

echo "Cloud Orchestration @ RESOURCE_GROUP: "$RESOURCE_GROUP" | LOCATION: "$LOCATION
#Create Azure Container Registry
export CONTAINER_REGISTRY_NAME=$PROJECT_PREFIX"cr"
export CONTAINER_REGISTRY_SKU=Basic
export REPO_DOMAIN=$CONTAINER_REGISTRY_NAME".azurecr.io"
echo "1. Creating Container Registry: "$CONTAINER_REGISTRY_NAME
export CONTAINER_REGISTRY_EXISTS=$(az acr list --resource-group $RESOURCE_GROUP --query "[?name=='$CONTAINER_REGISTRY_NAME'].name" -o tsv)

if [ -z "$CONTAINER_REGISTRY_EXISTS" ]; then
    echo "Container Registry does not exist, creating one. . ."
    az acr create \
      --resource-group $RESOURCE_GROUP \
      --name $CONTAINER_REGISTRY_NAME \
      --sku $CONTAINER_REGISTRY_SKU \
      --location $LOCATION
else
    echo "Container Registry already exist."
fi

echo "Fetching ACR Credentials"
az acr update --name $CONTAINER_REGISTRY_NAME --admin-enabled true --output none
export ACR_USERNAME=$(az acr credential show --name $CONTAINER_REGISTRY_NAME --resource-group $RESOURCE_GROUP --query "username")
export IMAGE_NAME=$PROJECT_PREFIX_UNDERSCORE"_image_7b_model"
echo "Building Docker Image locally: "$IMAGE_NAME
docker build -t $IMAGE_NAME -f deployment/dockerfile . --progress=plain --build-arg MODEL_SIZE=$MODEL_SIZE
echo "-----------------------------------------------------------"
echo "ACR login Repo: -name "$CONTAINER_REGISTRY_NAME
az acr login --name $CONTAINER_REGISTRY_NAME
echo "Pushing latest image"
docker tag $IMAGE_NAME $REPO_DOMAIN/$IMAGE_NAME:latest
docker push $REPO_DOMAIN/$IMAGE_NAME:latest
echo "Done uploading image step"

# # Create API Management resource...
# export APIM_NAME=$PROJECT_PREFIX_DASH"-apimgt"
# export PUBLISHER_EMAIL=$USER_EMAIL
# export PUBLISHER_NAME=$USER_NAME
# export APIM_SKU="Developer"
# echo "1. Creating Log Analytics Workspace for Container App. . ."
# export APIM_EXISTS=$(az apim list --resource-group $RESOURCE_GROUP --query "[?name=='$APIM_NAME'].name" -o tsv)
# if [ -z "$APIM_EXISTS" ]; then
#     echo "API Management instance does not exist, creating one. . ."
#     az apim create \
#         --name $APIM_NAME \
#         --resource-group $RESOURCE_GROUP \
#         --publisher-email $PUBLISHER_EMAIL \
#         --publisher-name $PUBLISHER_NAME \
#         --sku-name $APIM_SKU \
#         --location $LOCATION
# else
#     echo "API Management already exist."
# fi
# export APIM_IP=$(az apim show --name $APIM_NAME --resource-group $RESOURCE_GROUP --query "publicIpAddresses[0]")
# export APIM_IP=$(echo $APIM_IP | tr -d '"')
# echo "Got APIM_IP: "$APIM_IP

#Create Log analytics workspace for container app
export LOG_ANALYTICS_WORKSPACE=$PROJECT_PREFIX_DASH"-la"
echo "2. Creating Log Analytics Workspace for Container App. . ."
export LOG_ANALYTICS_EXISTS=$(az monitor log-analytics workspace list --resource-group $RESOURCE_GROUP --query "[?name=='$LOG_ANALYTICS_WORKSPACE'].name" -o tsv)
if [ -z "$LOG_ANALYTICS_EXISTS" ]; then
    echo "Log Analytics Workspace does not exist, creating one. . ."
    az monitor log-analytics workspace create \
      --resource-group $RESOURCE_GROUP \
      --workspace-name $LOG_ANALYTICS_WORKSPACE \
      --location $LOCATION
else
    echo "Log Analytics Workspace already exist. . ."
fi

# Get the Log Analytics workspace client ID and key for diagnostics settings
export WORKSPACE_ID=$(az monitor log-analytics workspace show \
  --resource-group $RESOURCE_GROUP \
  --workspace-name $LOG_ANALYTICS_WORKSPACE \
  --query customerId -o tsv)
export WORKSPACE_KEY=$(az monitor log-analytics workspace get-shared-keys \
  --resource-group $RESOURCE_GROUP \
  --workspace-name $LOG_ANALYTICS_WORKSPACE \
  --query primarySharedKey -o tsv)

# Create the container app environment if it does not already exist
echo "3. Creating Container App Environment for Container App. . ."
export CONTAINER_ENV_NAME=$PROJECT_PREFIX_DASH"-ce"
export CONTAINER_ENV_EXISTS=$(az containerapp env list --resource-group $RESOURCE_GROUP --query "[?name=='$CONTAINER_ENV_NAME'].name" -o tsv)

if [ -z "$CONTAINER_ENV_EXISTS" ]; then
    echo "Container App Environment does not exist, creating one: "$CONTAINER_ENV_EXISTS
    az containerapp env create \
      --enable-workload-profiles \
      --name $CONTAINER_ENV_NAME \
      --resource-group $RESOURCE_GROUP \
      --location $LOCATION \
      --logs-workspace-id $WORKSPACE_ID \
      --logs-workspace-key $WORKSPACE_KEY \
      --enable-dedicated-gpu true
else
    echo "Container App Environment already exist: "$CONTAINER_ENV_EXISTS
fi

echo "3. Creating Container App"
export CONTAINER_NAME=$PROJECT_PREFIX_DASH"-ca"
export CONTAINER_EXISTS=$(az containerapp list --resource-group $RESOURCE_GROUP --query "[?name=='$CONTAINER_NAME'].name" -o tsv)
# Create the container app

if [ -z "$CONTAINER_EXISTS" ]; then
    echo "Container App does not exist, creating one. . ."
    az containerapp create \
    --name $CONTAINER_NAME \
    --resource-group $RESOURCE_GROUP \
    --environment $CONTAINER_ENV_NAME \
    --image $REPO_DOMAIN/$IMAGE_NAME:latest \
    --target-port 80 \
    --ingress 'external' \
    --query 'configuration.ingress.fqdn' \
    --cpu 24 \
    --memory 220Gi \
    --registry-server $REPO_DOMAIN \
    --registry-username $ACR_USERNAME \
    --min-replicas 1 \
    --max-replicas 1 \
    --workload-profile-name "gpu" 
    
    echo "Exposing container app to: "$APIM_IP
    
    az containerapp ingress enable \
      --name $CONTAINER_NAME \
      --resource-group $RESOURCE_GROUP \
      --taarget-port 80 \
      --allow-insecure
else
    echo "Container App already exist. . ."
fi

# #Creatingn /backend endpoint under APIM
# echo "Creating APIM /backend method. . ."
# export CONTAINER_APP_URL=$(az containerapp show --name $CONTAINER_NAME --resource-group $RESOURCE_GROUP --query "properties.configuration.ingress.fqdn" --output tsv)
# export PROXY_PATH="backend"
# export PROXY_PATH_ID="backend-api"
# export APIM_API_EXISTS=$(az apim api list --service-name $APIM_NAME --resource-group $RESOURCE_GROUP --query "[?displayName=='$PROXY_PATH'].name" -o tsv)
# if [ -z "$APIM_API_EXISTS" ]; then
#   az apim api create \
#     --resource-group $RESOURCE_GROUP \
#     --service-name $APIM_NAME \
#     --api-id $PROXY_PATH_ID \
#     --path $PROXY_PATH \
#     --display-name $PROXY_PATH \
#     --service-url "https://"$CONTAINER_APP_URL \
#     --protocols https \
#     --description "This is an example API for demonstration." \
#     --api-type http \
#     --no-wait \
#     --subscription-required true

#   az apim api operation create \
#     --resource-group $RESOURCE_GROUP \
#     --service-name $APIM_NAME \
#     --api-id $PROXY_PATH_ID \
#     --operation-id get \
#     --display-name "Get" \
#     --method GET \
#     --url-template "/*" \
#     --description "Retrieve resource" \
#     --output none

#   az apim api operation create \
#     --resource-group $RESOURCE_GROUP \
#     --service-name $APIM_NAME \
#     --api-id $PROXY_PATH_ID \
#     --operation-id post \
#     --display-name "Post" \
#     --method POST \
#     --url-template "/*" \
#     --description "Create resource" \
#     --output none
# else
#     echo "APIM /backend method already exists. . ."
# fi

# export SUBSCRIPTION_ID=$(az account show --query "id" -o tsv)
# export APIM_URL=$(az apim show --name $APIM_NAME --resource-group $RESOURCE_GROUP --query "gatewayUrl" --output tsv)
# export APIM_API_KEY=$(az rest --method post --uri /subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.ApiManagement/service/$APIM_NAME/subscriptions/master/listSecrets?api-version=2022-08-01 --query 'primaryKey')
# export APIM_API_KEY=$(echo $APIM_API_KEY | tr -d '"')

# export link=$APIM_URL"/"$PROXY_PATH"?subscription-key="$APIM_API_KEY
# echo "Application URL: "$link