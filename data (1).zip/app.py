import os
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st
import chromadb
import pandasai

from src.scripts.file_operations.delete_files import delete_logs, delete_files_in_directory
from src.scripts.file_query.ppt_query import PPTQuery
from src.scripts.file_query.excel_query import ExcelQuery
from src.scripts.file_query.word_query import WordQuery
from src.scripts.file_operations.excel_splitter import split_sheets
from src.scripts.file_operations.pdf_data_extraction import PDFDataProcessor
from src.scripts.document_query import query

# Setup temporary folder and refresh support
def setup_temp_folder():
    if 'temp_folder' not in st.session_state:
        with tempfile.TemporaryDirectory() as temp_dir:
            print(f'Temporary directory created : {temp_dir}')
            os.environ['BASE_DIR'] = temp_dir
            st.session_state['temp_folder'] = temp_dir
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

setup_temp_folder()

# Initialize ChromaDB client and collection
chroma_client = chromadb.Client()
collection_test = chroma_client.get_or_create_collection(name="test")
TOGETHER_AI_API_KEY = os.getenv('TOGETHER_AI_API_KEY')

chat_messages = []
data_dir = "data"
if not os.path.exists(data_dir):
        os.makedirs(data_dir)
delete_files_in_directory(data_dir)

if 'collection_made' not in st.session_state:
    st.session_state['collection_made'] = False

if 'uploaded_files' not in st.session_state:
    st.session_state['uploaded_files'] = []

upload_folder = os.path.join(st.session_state['temp_folder'], 'data', 'raw-data')

if not os.path.exists(upload_folder):
    os.makedirs(upload_folder)
    print(f'Upload folder created at: {upload_folder}')

# Function to fetch PDF files
def fetch_files():
    try:
        f  = []
        files = [file for file in os.listdir(upload_folder)]  
        return files
    except Exception as e:
        st.error(f"Failed to read the directory: {e}")
        return []

# Function to delete a specific file
def delete_file(filename):
    try:
        os.remove(Path(upload_folder, filename))
    except Exception as e:
        st.error(f"Failed to delete the file: {e}")


# Function to upload files
def upload_files(uploaded_files):
    try:
        if uploaded_files is not None:
            for uploaded_file in uploaded_files:
                save_path = Path(upload_folder, uploaded_file.name)
                with open(save_path, 'wb') as f:
                    f.write(uploaded_file.getbuffer())
            return True
    except Exception as e:
        st.error(f"Failed to upload files: {e}")
        return False


# File Uploader in the sidebar
with st.sidebar:
    st.header("Settings")
    with st.expander("Parameters"):
        temperature = st.slider('temperature', 0.01, 1.0, 0.70, step=0.01)
        top_k = st.slider('top_k', 1, 20, 1, step=1)
        max_new_token = st.slider('Output length', 1, 500, 500, step=1)
    
with st.sidebar:
    st.header("Upload Files")
    with st.form("my-form", clear_on_submit=True):
        files = st.file_uploader("FILE UPLOADER", accept_multiple_files=True)
        submitted = st.form_submit_button("UPLOAD!")

    if submitted and files is not None:
        upload_status = upload_files(files)
        if upload_status:
            st.write("FILES UPLOADED!")
        else:
            st.write("UPLOAD FAILED!")


# Display uploaded files with an option to delete
st.sidebar.subheader("Uploaded Files")
files = fetch_files()
session_files = list(set(files) - set(st.session_state['uploaded_files']))
if files:
    st.session_state['uploaded_files'] = files
if len(session_files) and st.session_state['collection_made']:
    st.session_state['collection_made'] = False
    files = session_files
else:
    pass

if files or st.session_state['uploaded_files']:
    for file in st.session_state['uploaded_files']:
        file_col1, file_col2 = st.sidebar.columns([3, 1])
        file_col1.write(file)
        delete_button = file_col2.button("❌", key=file)
        if delete_button:
            delete_file(file)
            st.success("File deleted successfully!")
else:
    st.sidebar.write("No files found.")

# Data extraction and collection building
if len(files) > 0 and not st.session_state['collection_made']:
    with st.status("Extracting Data") as status:
        for file in files:            
            st.write("Processing File:", file)
            _, file_extension = os.path.splitext(file)
            if file_extension in ['.pptx', '.ppt']:
                ppt_loader = PPTQuery( file)
                st.session_state['collection'] = ppt_loader.data_extraction()
                st.session_state['collection_made'] = True
            elif file_extension in ['.xlsx', '.xls', '.csv']:
                csv_files = split_sheets(file)
                excel_loader = ExcelQuery(csv_files,temperature,max_new_token,top_k)
                st.session_state['collection'] = excel_loader.get_dataframe()
                st.session_state['collection_made'] = True    
            elif file_extension in ['.pdf']:
                pdf_loader = PDFDataProcessor(file)
                st.session_state['collection'] = pdf_loader.run()
                st.session_state['collection_made'] = True
            elif file_extension in ['.docx','.doc']:
                word_loader = WordQuery(file)
                st.session_state['collection'] =  word_loader.data_extraction()
                st.session_state['collection_made'] = True
            status.update(label="Data Extraction Complete!", state="complete", expanded=False)


# Query and response
if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message['role']):
        if isinstance(message['content'], pd.DataFrame):
            st.dataframe(message['content'])
        else:
            st.markdown(message['content'])

if prompt := st.chat_input("Say something"):
    with st.chat_message("user"):
        st.markdown(prompt)
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    if st.session_state['collection_made']:
        if isinstance(st.session_state['collection'], pandasai.smart_dataframe.Agent) or isinstance(st.session_state['collection'], pandasai.smart_datalake.SmartDatalake):
            delete_logs()
            response = query(prompt,st.session_state['collection'], source_type='dataframe')
        elif isinstance(st.session_state['collection'], type(collection_test)):   #['.pptx', '.ppt', '.pdf','.docx', '.doc']
            response = query(prompt,st.session_state['collection'],temperature, max_new_token, top_k,source_type='collection')
            
    else:
        response = query(prompt)
    
    if response is not None:
        if isinstance(response, pd.DataFrame):
            with st.chat_message("assistant"):
                if response.shape[0] > 2 or response.shape[1] > 3:
                    st.dataframe(response)  
                else:
                    st.markdown(response.to_markdown())
            st.session_state.messages.append({"role": "assistant", "content": response})
        else:
            with st.chat_message("assistant"):
                st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})

print("Query execution completed..", st.session_state['collection_made'])


