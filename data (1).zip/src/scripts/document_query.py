import os
from datetime import datetime
import ollama
from langchain_together import Together
# from openai import OpenAI 
import chromadb
from langchain_chroma import Chroma
from pandasai.llm.local_llm import LocalLLM
from langchain_core.messages import HumanMessage, AIMessage
from src.scripts.file_operations.chroma_db import query_data
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.llms import Ollama, OpenAI
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.llms import Ollama
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.output_parsers import StrOutputParser
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)


embedding_model = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
#embedding_model = embedding_functions.SentenceTransformerEmbeddingFunction(model_name='all-mpnet-base-v2')
TOGETHER_AI_API_KEY = os.getenv('TOGETHER_AI_API_KEY')
WORD_LIST = ["today", "last", "months", "days", "years", "day", "month", "year", "current", "right now", "currently", "next"]
use_local_llm = os.getenv('USE_LOCAL_LLM')
openai_api_key = os.getenv("OPENAI_API_KEY")
model_size = os.getenv("MODEL_SIZE")
chat_history = []


qa_prompt = ChatPromptTemplate.from_messages(
            [
                ("system", "You are an assistant for question-answering tasks.Use the following pieces of retrieved context to answer the question. If you don't know the answer, just say that you don't know. {context}"
                ),
                MessagesPlaceholder("chat_history"),
                ("human", "{input}"),
            ]
        )

contextualize_q_prompt = ChatPromptTemplate.from_messages(
            [
                ("system", "Given a chat history and the latest user questionwhich might reference context in the chat history, formulate a standalone question which can be understood without the chat history. Do NOT answer the question, just reformulate it if needed and otherwise return it as is. "
                ),
                MessagesPlaceholder("chat_history"),
                ("human", "{input}"),
            ]
        )


def query(query, data_source=None, temperature=0.7, max_tokens=500, top_k=1, source_type=None):
    """
    Generates a query response using either a local or external LLM and retrieves relevant information
    from a vector database or a data source.

    Args:
        query (str): The input query string.
        data_source (Optional[object]): An optional data source object to chat with.
        temperature (float): The sampling temperature to use for the LLM. Default is 0.7.
        max_tokens (int): The maximum number of tokens to generate. Default is 500.
        top_k (int): The number of top results to consider for the LLM. Default is 1.
        source_type (Optional[str]): The type of source to retrieve information from ('collection' or 'dataframe').

    Returns:
        str: The generated response to the input query.
    """
    try:
        # Initialize Chroma client for persistent storage
        chroma_client = chromadb.PersistentClient(path=os.path.join(os.getenv("BASE_DIR"), 'collection'))
        
        # Define the local and external LLMs
        local_llm = Ollama(model=f"llama3:{model_size}")
        external_llm = Together(
            model="meta-llama/Llama-3-70b-chat-hf", 
            temperature=temperature, 
            max_tokens=max_tokens, 
            top_k=top_k,  
            together_api_key=TOGETHER_AI_API_KEY
        )
        
        # Select the appropriate LLM
        llm = external_llm if use_local_llm == "False" else local_llm

        # Set up the vector source for retrieving data
        vector_source = Chroma(
            client=chroma_client,
            collection_name='LAM-AI-Troubleshoot-test',
            embedding_function=embedding_model
        ).as_retriever()

        # Create a history-aware retriever
        history_aware_retriever = create_history_aware_retriever(llm, vector_source, contextualize_q_prompt)

        # Create the question-answer chain
        question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)

        # Create the LLM retrieval chain
        llm_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)

        if source_type == 'collection':
            response = llm_chain.invoke({"input":query, "chat_history": chat_history})['answer']

        elif source_type == 'dataframe':
            today_date = datetime.today()
            formatted_date = today_date.strftime("%d %B %Y")
            if any(word in query for word in WORD_LIST):
                query = query + f" Today's date is {formatted_date}"
            response = data_source.chat(query)
        else:
            response = llm_chain.invoke({"input": query, "chat_history": chat_history})['answer']

        chat_history.append(HumanMessage(content=query))
        chat_history.append(AIMessage(content=response))
        return response
    except Exception as e:
        print("Error in generating query results")



