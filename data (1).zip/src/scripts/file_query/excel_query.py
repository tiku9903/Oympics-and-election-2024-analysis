from pandasai import SmartDataframe, SmartDatalake, Agent
from pandasai.llm.local_llm import LocalLLM
import pandas as pd
from pandasai.llm import OpenAI
from langchain_together import Together
import os
# from langchain_community.llms.ollama import Ollama

TOGETHER_AI_API_KEY = os.getenv('TOGETHER_AI_API_KEY')
use_local_llm = os.getenv('USE_LOCAL_LLM')
MODEL_URL = "http://localhost:11434/v1"
openai_api_key = os.getenv("OPENAI_API_KEY")
model_size = os.getenv("MODEL_SIZE")

class ExcelQuery():
    def __init__(self,file_list,temperature=0.7, max_tokens=500, top_k=1):
        self.file_list = file_list
        if use_local_llm == 'True':
            llm = LocalLLM(api_base = MODEL_URL, model= f"llama3:{model_size}")
            # llm = Ollama(model = 'llama3:latest')
        else:
            llm = OpenAI(api_token=openai_api_key,model_name = "gpt-4o")
            llm


        if len(self.file_list)>1:
            dataframes = [] 
            for file_path in self.file_list:
                df = pd.read_csv(file_path, encoding='utf-8') 
                dataframes.append(df)
            self.dataframe_chat = SmartDatalake(dataframes, config={"llm": llm})
        else:
            dataframe = pd.read_csv(self.file_list[0], encoding='utf-8')
            self.dataframe_chat = Agent(dataframe, config={"llm": llm})


    def get_dataframe(self):
        return self.dataframe_chat
    
