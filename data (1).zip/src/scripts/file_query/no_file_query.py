import requests

MODEL_URL = "http://localhost:11434/api/generate"




def query(query):
    response = requests.post(MODEL_URL, json=  {
        "model": "mixtral:8x7b",
        "prompt": f"""You re an assistant that will provide answer to questions, Query: {query}""",
        "stream": False
        })
    print(response)
    return response.json().get("response", "No response generated.")