import os
from src.scripts.file_operations.ppt_data_extraction import PPTDataExtraction

# base_directory = os.environ['BASE_DIR']
# upload_folder = os.path.join(base_directory, 'data', 'raw-data')
class PPTQuery():
    def __init__(self,file_path):
        self.base_directory = os.environ['BASE_DIR']
        self.upload_folder = os.path.join(self.base_directory, 'data', 'raw-data')
        self.file_path = f"{self.upload_folder}/{file_path}"

    def data_extraction(self):
        try:
            if os.path.exists(self.file_path):
                extraction = PPTDataExtraction(self.file_path)
                collection = extraction.run()
                return collection
        except Exception as e:
            print("Error in ppt data extraction. ", e)
        
