import pandas as pd
import os
import shutil
import concurrent.futures

# upload_data_dir = r"data/raw-data"
# save_dir_path = r"data/csv-data"

def process_sheet(file_path, sheet_name, save_dir_path):
    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        csv_file_name = os.path.join(save_dir_path, f"{sheet_name}.csv")
        df.to_csv(csv_file_name, index=False)
    except Exception as e:
        print("Error in processing sheet file. ", e)

def split_sheets(file_name):
    base_directory = os.environ['BASE_DIR']
    upload_data_dir = os.path.join(base_directory, 'data', 'raw-data')
    save_dir_path = os.path.join(base_directory, 'data', 'csv-data')
    try:
        if not os.path.exists(save_dir_path):
            os.makedirs(save_dir_path)
        file_path = os.path.join(upload_data_dir, file_name)
        _, file_extension = os.path.splitext(file_path)

        if file_extension in ['.xls', '.xlsx']:
            if file_extension in ['.xls', '.xlsx']:
                sheet_names = pd.ExcelFile(file_path).sheet_names 
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    futures = [executor.submit(process_sheet, file_path, sheet_name, save_dir_path) for sheet_name in sheet_names]
                    concurrent.futures.wait(futures)
            print("Excel file had been distributed...")
        elif file_extension == '.csv':
            new_file_path = os.path.join(save_dir_path, file_name)
            shutil.copy(file_path, new_file_path)
            print("Single CSV file uploaded...")

        print("CSV files have been created for each sheet.")
        files = [os.path.join(save_dir_path, file) for file in os.listdir(save_dir_path)]
        return files
    except Exception as e:
        print("Error in splitting sheets")