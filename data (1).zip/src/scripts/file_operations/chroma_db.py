import os
import re
import json
import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
# from sentence_transformers import SentenceTransformer
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
base_dir =  os.getenv('BASE_DIR')

class ChromaDBQuerying():
    """
    A class to handle querying of documents stored in a ChromaDB collection.
    Attributes:
        chroma_client (chromadb.Client): The ChromaDB client instance.
        collection (chromadb.Collection): The ChromaDB collection instance.
        file_type (str): The type of the file being processed.
        json_filepath (str): The path to the JSON file containing the document data.
        data (dict): The data loaded from the JSON file.
    """
    def __init__(self, file_path, file_type):
        """
        Initializes the ChromaDBQuerying class with file path and type.
        Parameters:
            file_path (str): The path to the JSON file containing document data.
            file_type (str): The type of the file being processed.
        """
        self.base_dir =  os.getenv('BASE_DIR')
        self.chroma_client = chromadb.PersistentClient(path=os.path.join(self.base_dir,'collection'))

        embedding_model = embedding_functions.SentenceTransformerEmbeddingFunction(model_name='all-mpnet-base-v2')
        #embedding_model = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

        self.collection = self.chroma_client.get_or_create_collection(name="LAM-AI-Troubleshoot-test")
        self.file_type = file_type
        self.json_filepath = file_path
        with open(self.json_filepath, "r", encoding="utf-8") as file:
            self.data = json.load(file)

    def run(self):
        """
        Runs the process of preparing and adding documents to the ChromaDB collection.
        Returns:
            chromadb.Collection: The ChromaDB collection instance with added documents.
        """
        if self.file_type in ['.ppt','.pptx']: 
            documents, metadatas, ids = self.prepare_ppt_documents()
        elif self.file_type in ['.docx','.doc']:
            documents, metadatas, ids = self.prepare_word_documents()
        elif self.file_type in ['.pdf']:
            documents, metadatas, ids = self.prepare_pdf_documents()
        collection = self.add_data_to_collection(documents, metadatas, ids)
        return collection

    def table_to_string(self, table):
        """
        Converts a table dictionary to a string summary.
        Parameters:
            table (dict): The table data as a dictionary.
        Returns:
            str: The table data converted to a string summary.
        """
        try:
            """Convert table dictionary to a string summary."""
            summary_parts = []
            for section, entries in table.items():
                section_summary = f"Section: {section}\n"
                entries_summary = "\n".join([f"{key}: {value}" for key, value in entries.items()])
                summary_parts.append(section_summary + entries_summary)
            return "\n\n".join(summary_parts)
        except Exception as e:
            print(f"Error in converting table data to string. ", e)
    
    def text_to_string(self, data):
        """
        Converts text data to a string.
        Parameters:
            data (dict): The text data as a dictionary.
        Returns:
            str: The text data converted to a string.
        """
        try:
            summary = []
            for section, entries in data.items():
                entries_summary = "\n".join([f"{section}: {entries}" ])
                summary.append(entries_summary)
            return "\n\n".join(summary)
        except Exception as e:
            print(f"Error in converting text data to string. ", e)
    
    def smart_data_to_string(self, smart_data):
        """
        Converts a list of smart data to a formatted string.
        Parameters:
            smart_data (list): The list of smart data
        Returns:
            str: The smart data converted to a formatted string.
        """
        try:
            """Convert smart data list to a formatted string."""
            if smart_data:
                return "\n".join(smart_data)
            return ""
        except Exception as e:
            print(f"Error in smart data to string. ", e)

    def prepare_pdf_documents(self):
        """
        Returns:
            tuple: A tuple containing lists of documents, metadatas, and ids.
        """
        try:
            documents = []
            metadatas = []
            ids = []

            for page_key, page_data in self.data.items():
                if isinstance(page_data, str):
                    document = str(page_data).strip()
                documents.append(document)
                metadatas.append({"source_file": self.json_filepath, "page_number": page_key})
                ids.append(f"{page_key}")

            return documents, metadatas, ids
        except Exception as e:
            print(f"Error in converting pdf data to chromadb documents. ", e)

    def prepare_ppt_documents(self):
        """
        Returns:
            tuple: A tuple containing lists of documents, metadatas, and ids.
        """
        try:
            documents = []
            metadatas = []
            ids = []

            for page_key, page_data in self.data.items():
                if isinstance(page_data, dict):
                    if 'text' in page_data or 'table' in page_data:
                        text = page_data.get("text", "")
                        table_summary = self.table_to_string(page_data.get("table", {})) if page_data.get("table") else ""
                        document = f"{text}\n\n{table_summary}".strip()
                elif isinstance(page_data, str):
                    document = str(page_data).strip()
                documents.append(document)
                metadatas.append({"source_file": self.json_filepath, "page_number": page_key})
                ids.append(f"{page_key}")

            return documents, metadatas, ids
        except Exception as e:
            print(f"Error in converting ppt data to chromadb documents. ", e)
    
    def prepare_word_documents(self):
        """
        Returns:
            tuple: A tuple containing lists of documents, metadatas, and ids.
        """
        try:
            documents = []
            metadatas = []
            ids = []
            for data_type, value in self.data.items():
                if data_type == "text":
                    document = self.text_to_string(value)
                elif data_type == "image_context":
                    document = self.text_to_string(value)
                elif data_type == "table":
                    document = self.table_to_string(value)
                else:
                    document = ''

                
                documents.append(document)
                metadatas.append({"source_file": self.json_filepath, "data_type": data_type})
                ids.append(f"{data_type}")

            return documents, metadatas, ids
        except Exception as e:
            print("Error in converting word data to chromadb documents. ", e)

    def add_data_to_collection(self, documents, metadatas, ids):
        """
        Adds documents to the ChromaDB collection.
        Parameters:
            documents (list): The list of documents to add.
            metadatas (list): The list of metadatas corresponding to the documents.
            ids (list): The list of ids corresponding to the documents.
        Returns:
            chromadb.Collection: The ChromaDB collection instance with added documents.
        """
        try:
            for doc, metadata, id in zip(documents, metadatas, ids):
                if len(doc)>0:
                    self.collection.add(
                        documents=[doc],
                        metadatas=[metadata],
                        ids=[id]
                    )
            print("data added to collection")
            return self.collection
        except Exception as e:
            print("Error in adding data to collection. ", e)

def query_data(collection, query):
    """
    Queries the ChromaDB collection and returns the top result.
    Parameters:
        collection (chromadb.Collection): The ChromaDB collection instance.
        query (str): The query text.
    Returns:
        str: The top result from the query.
    """
    try:
        results = collection.query(
            query_texts=query,
            n_results=3
        )
        return results["documents"][0][0]
    except Exception as e:
        print("Error in getting query result from chromadb. ", e)