import os
import shutil

def delete_logs():
    file_path = r'pandasai.log'
    cache_folder = r"cache/"

    if os.path.exists(file_path): 
        try:
            os.remove(file_path)
        except PermissionError:
            with open(file_path, 'w') as file:
                pass
            print("Failed to delete log file due to permission issues")

    if os.path.exists(cache_folder):
        try:
            shutil.rmtree(cache_folder)  # This removes a directory and all its contents
        except PermissionError:
            print("Failed to delete cache directory due to permission issues")
        except OSError as e:
            print(f"Failed to delete cache directory: {e}") 
            



def delete_files_in_directory(directory):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except PermissionError as e:
            print(f"PermissionError: {e}. Skipping {file_path}")
        except Exception as e:
            print(f"Error: {e}. Skipping {file_path}")
    