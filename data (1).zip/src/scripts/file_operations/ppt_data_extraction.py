import pptx
import pandas as pd
import os
import numpy as np
import json
import re
from spire.presentation.common import *
from spire.presentation import *
from io import BytesIO
from PIL import Image
from src.scripts.file_operations.chroma_db import ChromaDBQuerying
from src.scripts.file_operations.image_context import ImageDescription
# from chroma_db import ChromaDBQuerying
# from image_context import ImageDescription

# base_directory = os.environ['BASE_DIR']
# upload_data_dir = os.path.join(base_directory, 'data', 'raw-data')
# extracted_data_dir = os.path.join(base_directory, 'data', 'extracted-data')
# image_dir = os.path.join(base_directory, 'data', 'ppt_extracted_images')

class PPTDataExtraction():
    """
    A class to extract data from a PowerPoint (.pptx) file and format it into a structured JSON format.
    Attributes:
        ppt_file_path (str): The file path to the PowerPoint file.
    """
    def __init__(self, ppt_file_path):
        """
        Initializes the PPTDataExtraction with the provided PowerPoint file path.
        Args:
            ppt_file_path (str): The file path to the PowerPoint file.
        """
        self.base_directory = os.environ['BASE_DIR']
        self.upload_data_dir = os.path.join(self.base_directory, 'data', 'raw-data')
        self.extracted_data_dir = os.path.join(self.base_directory, 'data', 'extracted-data')
        self.image_dir = os.path.join(self.base_directory, 'data', 'ppt_extracted_images')

        self.ppt_file_path = ppt_file_path
        if not os.path.exists(self.extracted_data_dir):
            os.makedirs(self.extracted_data_dir)


    def run(self):
        """
        Extracts and formats data from the PowerPoint file and stores it in a JSON file.
        Returns:
            collection (object): The collection of extracted data stored in the ChromaDB.
        """
        ppt_file_name = self.ppt_file_path.split('/')[-1]
        json_file_name = ppt_file_name.replace('.pptx','.json')
        json_file_path = f"{self.extracted_data_dir}/{json_file_name}"
        self.data_fomating(json_file_path)
        chromadb = ChromaDBQuerying(json_file_path,'.pptx')
        collection = chromadb.run()
        return collection 


    def data_extraction(self):
        """
        Extracts tables, text, images, and hyperlinks from the PowerPoint file.
        Returns:
            data (dict): The extracted data structured by slides.
        """
        try:
            prs = pptx.Presentation(self.ppt_file_path)

            counter = 1
            data = {}
            image_counter = 0

            for slide in prs.slides:
                table_data = []
                text_data = []
                for shape in slide.shapes:
                    if shape.is_placeholder:
                        placeholder = shape.placeholder_format
                        if placeholder is not None:
                            if  shape.has_table:
                                table = shape.table
                                num_rows = len(table.rows)
                                num_cols = len(table.columns)
                                headers = [cell.text.strip() for cell in table.rows[0].cells]
                                headers += [""] * (num_cols - len(headers))

                                for i in range(1, num_rows):
                                    row_data = {}
                                    for j in range(num_cols):
                                        cell = table.cell(i, j)
                                        text = cell.text.strip()

                                        if not text and j > 0:
                                            text = row_data.get(headers[j-1], "")
                                        header = headers[j] if headers[j] else f"Unnamed Column {j}"
                                        row_data[header] = text
                                    table_data.append(row_data)
                            elif shape.has_text_frame:
                                for paragraph in shape.text_frame.paragraphs:
                                    for run in paragraph.runs:
                                        text_data.append(run.text.strip())
                    else:
                        if shape.shape_type == 19:  
                            table = shape.table
                            headers = [cell.text.strip() for cell in table.rows[0].cells]
                            for idx in range(1, len(table.rows)):
                                row_data = {headers[i]: cell.text.strip() for i, cell in enumerate(table.rows[idx].cells)}
                                table_data.append(row_data)
                        elif shape.has_text_frame:
                            for paragraph in shape.text_frame.paragraphs:
                                for run in paragraph.runs:
                                    text_data.append(run.text.strip())
                
                images = self.get_images(slide, image_counter, counter)
                hyperlink = self.get_hyperlinks(slide)
                data[f"page_{counter}"] = {"table" : table_data, "text" : text_data, "url": hyperlink, "images": images}
                counter +=1
            return data
        except Exception as e:
            print(f"Error in extracting text and tables from ppt file {self.ppt_file_name}. ", e)

    def row_merger_fix(self,data):
        """
        Fixes merged rows in the extracted table data.
        Args:
            data (pd.DataFrame): The DataFrame containing the table data.
        Returns:
            pd.DataFrame: The DataFrame with fixed merged rows.
        """
        try:
            data = data.replace("", np.nan)
            data.fillna(method='ffill', inplace=True)
            return data
        except Exception as e:
            print(f"Error in row merger fix in ppt file {self.ppt_file_name}. ", e)

    def column_merger_fix(self, data):
        """
        Fixes merged columns in the extracted table data.
        Args:
            data (pd.DataFrame): The DataFrame containing the table data.
        Returns:
            pd.DataFrame: The DataFrame with fixed merged columns.
        """
        try:
            for i in range(1, len(data.columns)):
                if "Unnamed" in data.columns[i]:
                    data.columns.values[i] = data.columns[i - 1]
            return data
        except Exception as e:
            print(f"Error in column merger in ppt file {self.ppt_file_name}. ", e)

    def corrected_df(self, data):
        """
        Corrects the DataFrame to handle duplicate column names and consolidates data into lists.
        Args:
            data (pd.DataFrame): The DataFrame containing the table data.
        Returns:
            pd.DataFrame: The corrected DataFrame.
        """
        try:
            df_corrected = data.copy()
            cols = pd.Series(df_corrected.columns)
            for dup in cols[cols.duplicated()].unique():
                cols[cols[cols == dup].index.values.tolist()] = [dup + '.' + str(i) if i != 0 else dup for i in range(sum(cols == dup))]

            df_corrected.columns = cols

            for col in df_corrected.columns:
                if '.' in col:
                    original_col = col.split('.')[0]
                    df_corrected[original_col] = df_corrected.apply(lambda x: x[original_col] + [x[col]] if x[col] else x[original_col], axis=1)
                    df_corrected.drop(columns=[col], inplace=True)
                else:
                    df_corrected[col] = df_corrected[col].apply(lambda x: [x] if x else [])

            return df_corrected
        except Exception as e:
            print(f"Error in correcting dataframe in ppt file {self.ppt_file_name}. ", e)
    
    def smartart_extraction(self ):
        """
        Extracts SmartArt data from the PowerPoint file.
        Returns:
            extracted_data (dict): The extracted SmartArt data structured by slides.
        """
        try:
            presentation = Presentation()
            presentation.LoadFromFile(self.ppt_file_path)
            extracted_data = {}
            for index, slide in enumerate(presentation.Slides):
                data = []
                for shape in slide.Shapes:
                    if isinstance(shape, ISmartArt):
                        smartArt = shape
                        for node in smartArt.Nodes:
                            data.append(node.TextFrame.Text)
                    extracted_data[f"page_{index+1}"] = data
            return extracted_data
        except Exception as e:
            print(f"Error in extracting smartart from ppt file {self.ppt_file_name}. ", e)

    def data_cleaning(self,extracted_data):
        """
        Cleans and formats the extracted data.
        Args:
            extracted_data (dict): The extracted data.
        Returns:
            dict: The cleaned and formatted data.
        """
        try:
            for page in extracted_data:
                for element in extracted_data[page]:
                    value = extracted_data[page][element]
                    if len(value)>0:
                        if isinstance(value,list):
                            result_string = '\n'.join(value)
                            extracted_data[page][element] = result_string
                        elif isinstance(value,dict):
                            for item in value:
                                for key in value[item]:
                                    result_string = '\n'.join(value[item][key])
                                    extracted_data[page][element][item][key] = result_string 
                    else:
                        extracted_data[page][element] = ''
            return extracted_data
        except Exception as e:
            print(f"Error in data cleaning in ppt file {self.ppt_file_name}. ", e)
    
    def data_fomating(self,json_file_path):
        """
        Formats the extracted data and saves it to a JSON file.
        Args:
            json_file_path (str): The file path to save the formatted JSON data.
        """
        try:
            extracted_data = self.data_extraction()
            for page in extracted_data.keys():
                if extracted_data[page]['table'] is not None:
                    data = pd.DataFrame(extracted_data[page]['table'])
                    data = self.row_merger_fix(data)
                    data = self.column_merger_fix(data)
                    data = self.corrected_df(data)
                    extracted_data[page]['table']  = data.to_dict()     
            extracted_data = self.data_cleaning(extracted_data)
            smart_art_data = self.smartart_extraction()
            for key in extracted_data:
                if key in smart_art_data: 
                    extracted_data[key]["smart_data"] = smart_art_data[key]
            
            image_description_genertor = ImageDescription()
            extracted_data = image_description_genertor.analyze_folder(self.image_dir, extracted_data, '.pptx')
            
            with open(json_file_path,'w') as f:
                json.dump(extracted_data,f)
        except Exception as e:
            print(f"Error in data formating in ppt file {self.ppt_file_name}. ", e)

    def get_hyperlinks(self, slide):
        """
        Extracts hyperlinks from a slide.
        Args:
            slide (pptx.slide.Slide): The slide to extract hyperlinks from.
        Returns:
            list: A list of extracted hyperlinks.
        """
        try:
            hyperlinks = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            if run.hyperlink is not None:                        
                                hyperlink = run.hyperlink                    
                                if hyperlink.address:
                                    hyperlinks.append(hyperlink.address)
                if hasattr(shape, "text"):    
                    text = shape.text
                    print(text)
                    match = re.findall(r'\b(?:https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|]', text, re.IGNORECASE)
                    if match:
                        hyperlinks.extend(match)
            
            print(hyperlinks)           
            return list(set(hyperlinks))
        except Exception as e:
            print(f"Error in getting hyperlinks from ppt file {self.ppt_file_name}. ", e)
    
    def get_images(self, slide, image_counter, counter):
        """
        Extracts images from a slide and saves them to the image directory.
        Args:
            slide (pptx.slide.Slide): The slide to extract images from.
            image_counter (int): The counter to number the images.
            counter (int): The slide number counter.
        Returns:
            list: A list of paths to the extracted images.
        """
        try:
            images = []
            if not os.path.exists(self.image_dir):
                os.makedirs(self.image_dir)
            for shape in slide.shapes:
                if shape.shape_type == 13:
                    image = shape.image
                    image_bytes = image.blob
                    image_stream = BytesIO(image_bytes)
                    img = Image.open(image_stream)
                    path = f"{self.image_dir}/image_{counter}_{image_counter}.png"
                    img.save(path)
                    image_counter += 1
                    images.append(path)
            return images
        except Exception as e:
            print(f"Error in getting images from ppt file {self.ppt_file_name}. ", e)

# if __name__ == "__main__":
#     file_path = r"data/raw-data/LAM_test.pptx"
#     if os.path.exists(file_path):
#         extraction = PPTDataExtraction(file_path)
#         extraction.run()
#     else:
#         print("file path is wrong")


