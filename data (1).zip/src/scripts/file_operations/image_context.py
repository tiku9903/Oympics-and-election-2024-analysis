import ollama
import os
import json
import base64
from openai import OpenAI

use_local_llm = os.getenv('USE_LOCAL_LLM')
openai_api_key = os.getenv("OPENAI_API_KEY")

class ImageDescription:
    """
    A class to analyze images within various document formats and provide detailed descriptions of those images.
    Attributes:
        model_name (str): The name of the model used for image analysis.
    """
    def __init__(self):
        """
        Initializes the ImageDescription class with the specified model name.
        """
        self.model_name = "llava:7b"


    def analyze_image(self, image_path,additional_data):
        """
        Analyzes a single image and provides a detailed description based on the content of the image and additional context.
        Args:
            image_path (str): The file path to the image to be analyzed.
            additional_data (str): Additional text data to provide context for the image analysis.
        Returns:
            str: The analysis result of the image or an error message if an exception occurs.
        """
        try:
            if use_local_llm:
                with open(image_path, 'rb') as image_file:
                    image_content = image_file.read()
                res = ollama.chat(
                    model=self.model_name,
                    messages=[
                        {
                            'role': 'user',
                            'content': f'Describe this image by considering text this image has and try to explain it thoroughly:{additional_data}',
                            'images': [image_content]
                        }
                    ]
                )
                return res['message']['content']
            else:
                with open(image_path, "rb") as image_file:
                    base64_image = base64.b64encode(image_file.read()).decode('utf-8')
                client = OpenAI(api_key = openai_api_key)
                context = f"Describe this image by considering text this image has and try to explain it thoroughly:{additional_data}"
                response = client.chat.completions.create(
                    model=os.environ["MODEL"],
                    messages=[
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": context},
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/jpeg;base64,{base64_image}",
                                        "detail": "high"
                                    },
                                },
                            ],
                        }
                    ],
                    max_tokens=4000,
                )


        except FileNotFoundError:
            return "Error: The specified image file was not found."
        except Exception as e:
            return f"An error occurred: {str(e)}"
    
    def analyze_folder(self, folder_path, json_data, file_type):
        """
        Analyzes all images in a specified folder based on the document type and updates the JSON data with image contexts.
        Args:
            folder_path (str): The path to the folder containing images.
            json_data (dict): The JSON data to be updated with image contexts.
            file_type (str): The type of document (".docx", ".pptx", ".pdf").
        Returns:
            dict: The updated JSON data with image contexts or an error message if an exception occurs.
        """
        try:
            if file_type == ".docx":
                if os.path.exists(folder_path):
                    image_description = self.analyze_docs_images(folder_path,json_data)
                    json_data["image_context"] = image_description
                    return json_data
                else:
                    json_data["image_context"] = ""
                    return json_data
            if file_type == ".pptx":
                if os.path.exists(folder_path):
                    json_data = self.analyze_ppt_images(json_data)
                    return json_data
            if file_type ==".pdf":
                if os.path.exists(folder_path):
                    json_data = self.analyze_pdf_folder(folder_path, json_data)
                    return json_data
        except Exception as e:
            print("Error in analyze folder function in image context. ", e)

    def analyze_docs_images(self,image_folder_path, json_data):
        """
        Analyzes images extracted from a Word document and updates the JSON data with the analysis results.
        Args:
            image_folder_path (str): The path to the folder containing images extracted from the Word document.
            json_data (dict): The JSON data to be updated with image contexts.
        Returns:
            dict: A dictionary containing image analysis results or an error message if an exception occurs.
        """
        try:
            results = {}
            for image_name in os.listdir(image_folder_path):
                image_path = os.path.join(image_folder_path, image_name)
                if os.path.isfile(image_path):
                    root, ext = os.path.splitext(image_name)
                    input_text = json_data.get(root, "")
                    try:
                        analysis_result = self.analyze_image(image_path, input_text)
                        results[image_name] = analysis_result
                    except Exception as e:
                        print(f"Error processing {image_name}: {e}")
            
            return results
        except Exception as e:
            print("Error in analyzing images extracted from word file. ", e)

    
    def analyze_ppt_images(self, json_data):
        """
        Analyzes images extracted from a PowerPoint presentation and updates the JSON data with the analysis results.
        Args:
            json_data (dict): The JSON data containing image paths and associated text.
        Returns:
            dict: The updated JSON data with image contexts or an error message if an exception occurs.
        """
        try:
            for page in json_data.keys():
                if len(json_data[page]['images'])>0:
                    result = {}
                    image_list = json_data[page]['images'].split('\n')
                    for image_path in image_list:
                        image_name = image_path.split('/')[-1]
                        additional_data = json_data[page]['text']
                        image_context = self.analyze_image(image_path,additional_data)
                        result[image_name] = image_context
                    json_data[page]['image_context'] = result
                else:
                    json_data[page]['image_context'] = ""
            return json_data 
        except Exception as e:
            print("Error in analyzing images from ppt file. ", e)

    def analyze_pdf_folder(self, folder_path, json_file_path):
        """
        Analyzes images extracted from a PDF and updates the JSON data with the analysis results.
        Args:
            folder_path (str): The path to the folder containing images extracted from the PDF.
            json_file_path (str): The path to the JSON file containing extracted text data.
        Returns:
            dict: A dictionary containing image analysis results or an error message if an exception occurs.
        """
        try:
            try:
                with open(json_file_path, 'r', encoding = "utf8") as file:
                    json_data = json.load(file)
            except Exception as e:
                print(f"Error loading JSON file: {e}")
                return {}

            results = {}
            for image_name in os.listdir(folder_path):
                image_path = os.path.join(folder_path, image_name)
                if os.path.isfile(image_path):
                    root, ext = os.path.splitext(image_name)
                    input_text = json_data.get(root, "")
                    try:
                        analysis_result = self.analyze_image(image_path, input_text)
                        results[image_name] = analysis_result
                    except Exception as e:
                        print(f"Error processing {image_name}: {e}")
            return results
        except Exception as e:
            print("Error in anaylzing images extracted from pdf. ", e)
    


    

