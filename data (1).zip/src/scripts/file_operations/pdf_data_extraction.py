import re
import json
import os
import io
from pypdf import PdfReader
from PIL import Image
import fitz  
import ollama
import requests
from langchain_together import Together
from src.scripts.file_operations.image_context import ImageDescription


from src.scripts.file_operations.chroma_db import ChromaDBQuerying
from src.scripts.file_operations.chroma_db import query_data


TOGETHER_AI_API_KEY = os.getenv('TOGETHER_AI_API_KEY')
MODEL_URL = "http://localhost:11434/api/generate"
add_image_context = os.getenv('ADD_IMAGE_CONTEXT')

# self.base_directory = os.getcwd()
# if self.base_directory.endswith("\\src"):
#     self.base_directory = os.path.dirname(self.base_directory)
    
#base_directory = os.environ['BASE_DIR']

class PDFTextExtractor:
    def __init__(self):
        self.patterns_to_remove = [
        r'Private & Confidential', r'Osool & Bakheet Investment Co., Riyadh, KSA - July 2020',
        r'Mixed Portfolio Real Estate Assets', r'\d+ of \d+', r'[\u0600-\u06FF]+',  # Arabic range
        r'[\u0600-\u06FF\uFB50-\uFDFF\uFE70-\uFEFF]+',  # Extended Arabic range
        r'\\', r'Page \d+ of \d+', r'WCRE - Valuation Report', r'-{3,}', r'Page', r'\.{3,}|\u2026'  # Ellipsis
    ]
        self.base_directory = os.environ['BASE_DIR']

    def clean_text(self, value):
        try:
            for pattern in self.patterns_to_remove:
                value = re.sub(pattern, '', value)
            value = value.replace('–', '-')
            value = value.replace("’", "'")
            value = value.replace("‘", "'")
            value = re.sub(r'\s+', ' ', value)
            value = re.sub(r'[^\w\s,.!?-]', '', value)
            return value.strip()
        except Exception as e:
            print(f"Error in cleaning text in pdf file. ", e)

    def process_pdf(self, pdf_path):
        try:
            reader = PdfReader(pdf_path)
            pages_text = {}
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    cleaned_text = self.clean_text(text)
                    pages_text[str(i)] = cleaned_text
            return pages_text
        except Exception as e:
            print("Error in processing pdf file. ", e)

    def save_to_json(self, data, output_path):
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True) 
            with open(output_path, 'w', encoding='utf-8') as json_file:
                json.dump(data, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            print("Error in saving json from pdf file. ", e)

class PDFImageExtractor:
    def __init__(self, pdf_path, output_folder):
        self.pdf_path = pdf_path
        self.output_folder = output_folder
        self.create_output_folder()

    def create_output_folder(self):
        try:
            if not os.path.exists(self.output_folder):
                os.makedirs(self.output_folder)
        except Exception as e:
            print("Error in creating ouput folder in pdf data extraction. ", e)


    def extract_images(self):
        try:
            extracted_images = []
            reader = PdfReader(self.pdf_path)
            for page_number, page in enumerate(reader.pages):
                if hasattr(page, 'images') and page.images:
                    for image_file_object in page.images:
                        extracted_images.append({
                            "page_number": page_number,
                            "image_name": image_file_object.name,
                            "image_data": image_file_object.data
                        })
            return extracted_images
        except Exception as e:
            print("Error in extracting images in pdf file. ", e)

    def convert_images(self, file_list):
        try:
            converted_images = []
            for file_dict in file_list:
                file_name = file_dict['image_name']
                pageno = file_dict['page_number']
                file_data = file_dict['image_data']

                if file_name.endswith('.jp2'):
                    im = Image.open(io.BytesIO(file_data))
                    width, height = im.size
                    if width > 100 and height > 100:
                        converted_images.append(pageno)
                else:
                    im = Image.open(io.BytesIO(file_data))
                    width, height = im.size
                    if width > 100 and height > 100:
                        converted_images.append(pageno)
            return converted_images
        except Exception as e:
            print("Error in converting images extracted from pdf file. ", e)

    def save_images(self, pages_list):
        try:
            zoom_x = 2.0  # horizontal zoom
            zoom_y = 2.0  # vertical zoom
            mat = fitz.Matrix(zoom_x, zoom_y)
            file = fitz.open(self.pdf_path)
            for i in set(pages_list):
                pic = file[i].get_pixmap(matrix=mat)
                pic.save(os.path.join(self.output_folder, f"{i}.png"))
        except Exception as e:
            print("Error in saving extracted images from pdf file. ", e)

def pdftextimage(json_file_path, image_analysis_path, output_json_path):
    try:
        with open(json_file_path, 'r', encoding = "utf8") as file:
            first_json = json.load(file)

        with open(image_analysis_path, 'r') as file:
            second_json = json.load(file)

        for key, value in second_json.items():
            root, ext = os.path.splitext(key)
            if root in first_json:
                first_json[root] += value

        with open(output_json_path, 'w') as file:
            json.dump(first_json, file, indent=4)
    except Exception as e:
        print("Error in pdftextimage function in pdf data extraction. ", e)

class PDFDataProcessor:
    """
    A class to process PDF files, extract text and images, analyze images, and merge data.
    Attributes:
        file_name (str): The name of the PDF file to process.
        self.base_directory (str): The base directory path.
        pdf_path (str): The full path to the PDF file.
        base_filename (str): The base name of the PDF file without extension.
        file_type (str): The file extension of the PDF file.
    """
    def __init__(self, file_name):
        self.file_name = file_name 
        self.base_directory = os.environ['BASE_DIR']
        self.pdf_path = os.path.join(self.base_directory,'data', 'raw-data', file_name)
        self.base_filename, self.file_type = os.path.splitext(os.path.basename(self.pdf_path))

    def process_text(self):
        """
        Extracts text from the PDF and saves it to a JSON file.
        Returns:
            str: The path to the JSON file containing the extracted text.
        """
        try:
            original_text_path = os.path.join(self.base_directory, "data", "json_files", f"{self.base_filename}_original_text.json")
            text_cleaner = PDFTextExtractor()
            cleaned_data = text_cleaner.process_pdf(self.pdf_path)
            text_cleaner.save_to_json(cleaned_data, original_text_path)
            return original_text_path
        except Exception as e:
            print(f"Error in extracting text from pdf file {self.file_name}. ", e)

    def extract_and_save_images(self):
        """
        Extracts images from the PDF and saves them to a specified folder.
        Returns:
            str: The path to the folder containing the extracted images.
        """
        try:
            image_output_folder = os.path.join(self.base_directory, "data", "pdf_images", f"{self.base_filename}_page")
            image_extractor = PDFImageExtractor(self.pdf_path, image_output_folder)
            extracted_images = image_extractor.extract_images()
            converted_list = image_extractor.convert_images(extracted_images)
            image_extractor.save_images(converted_list)
            return image_output_folder
        except Exception as e:
            print(f"Error in extracting and saving images from pdf file {self.file_name}. ", e)


    def analyze_images(self, image_output_folder, original_text_path):
        """
        Analyzes the extracted images and saves the analysis results to a JSON file.
        Args:
            image_output_folder (str): The path to the folder containing the extracted images.
            original_text_path (str): The path to the JSON file containing the extracted text.
        Returns:
            str: The path to the JSON file containing the image analysis results.
        """
        try:
            image_analysis_path = os.path.join(self.base_directory, "data", "json_files", f"{self.base_filename}_image_analysis_results.json")
            image_analyzer = ImageDescription()
            analysis_results = image_analyzer.analyze_folder(image_output_folder, original_text_path, self.file_type)
            with open(image_analysis_path, "w", encoding = "utf8") as file:
                json.dump(analysis_results, file, indent=4, ensure_ascii=False)
            return image_analysis_path
        except Exception as e:
            print(f"Error in analyzing images extracted from pdf file {self.file_name}. ", e)

    def merge_text_and_images(self, original_text_path, image_analysis_path):
        """
        Merges the extracted text and image analysis results into a single JSON file.
        Args:
            original_text_path (str): The path to the JSON file containing the extracted text.
            image_analysis_path (str): The path to the JSON file containing the image analysis results.
        Returns:
            str: The path to the JSON file containing the merged data.
        """
        try:
            output_json_path = os.path.join(self.base_directory, "data", "json_files", f"{self.base_filename}_text_image.json")
            pdftextimage(original_text_path, image_analysis_path, output_json_path)
            return output_json_path
        except Exception as e:
            print(f"Error in merging text and images data extracted from pdf file {self.file_name}. ", e)

    def run(self):
        """
        Runs the full processing pipeline: extracting text, extracting and analyzing images (if applicable),
        merging the results, and storing the final data in a database.
        Returns:
            collection: The collection object from the database after inserting the processed data.
        """
        print("Extracting PDF Text...")
        original_text_path = self.process_text()
        print("PDF Text Extraction  completed...")
        if add_image_context == 'True':
            image_output_folder = self.extract_and_save_images()
            image_analysis_path = self.analyze_images(image_output_folder, original_text_path)
            output_json_path = self.merge_text_and_images(original_text_path, image_analysis_path)
            print("Image analysis generated successfully...")
        else:
            output_json_path = original_text_path
        print("Data Generated Successfully...")
        
        chromadb = ChromaDBQuerying(output_json_path, self.file_type)
        collection = chromadb.run()
        return collection
    

def pdfquery(collection, query):
    local_llm = False
    chroma_result = query_data(collection, query)
    if local_llm:
        response = requests.post(MODEL_URL, json=  {
            "model": "mixtral:8x7b",
            "prompt": f"""You re an assistant that will provide answer to questions asked based on data {chroma_result}, Query: {query}""",
            "stream": False
            })
        print(response)
        return response.json().get("response", "No response generated.")

    else:
        llm = Together(
        model="meta-llama/Llama-3-70b-chat-hf", 
        temperature=0.7, 
        max_tokens=500, 
        top_k=1,  
        together_api_key= TOGETHER_AI_API_KEY
        )
        prompt = f"""You re an assistant that will provide answer to questions asked based on data {chroma_result}, Query: {query}""",
        response = llm.invoke(prompt)
        return response


