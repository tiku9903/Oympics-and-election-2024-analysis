from docx import Document
import re
import os
import json
from src.scripts.file_operations.chroma_db import ChromaDBQuerying
from src.scripts.file_operations.image_context import ImageDescription
# from chroma_db import ChromaDBQuerying
# from image_context import ImageDescription
add_image_context = os.getenv('ADD_IMAGE_CONTEXT')


# base_directory = os.environ['BASE_DIR']
# upload_data_dir = os.path.join(base_directory, 'data', 'raw-data')
# extracted_data_dir = os.path.join(base_directory, 'data', 'extracted-data')
# image_dir = os.path.join(base_directory, 'data', 'word_extracted_images')

class DocDataExtraction():
    """
    A class to handle the extraction of various data types from a Word document.
    Attributes:
    doc_file_path (str): Path to the Word document.
    base_filename (str): Base name of the file.
    file_type (str): File type extension.
    document (Document): Document object for the Word file.
    """
    def __init__(self,doc_file_path):
        """       
        Parameters:
        doc_file_path (str): Path to the Word document.
        """
        self.base_directory = os.environ['BASE_DIR']
        self.upload_data_dir = os.path.join(self.base_directory, 'data', 'raw-data')
        self.extracted_data_dir = os.path.join(self.base_directory, 'data', 'extracted-data')
        self.image_dir = os.path.join(self.base_directory, 'data', 'word_extracted_images')
        self.doc_file_path = doc_file_path
        if not os.path.exists(self.extracted_data_dir):
            os.makedirs(self.extracted_data_dir)
        if not os.path.exists(self.image_dir):
            os.makedirs(self.image_dir)
        self.document = Document(self.doc_file_path)
        self.base_filename, self.file_type = os.path.splitext(os.path.basename(doc_file_path))

    
    def run(self):
        """
        Run the data extraction process and store the extracted data in a ChromaDB collection.
        Returns:
        collection (ChromaDBCollection): Collection of extracted data.
        """
        doc_file_name = self.doc_file_path.split('/')[-1]
        json_file_name = doc_file_name.replace('.docx','.json')
        json_file_path = f"{self.extracted_data_dir}/{json_file_name}"
        self.data_extraction(self.image_dir,json_file_path)
        chromadb = ChromaDBQuerying(json_file_path,'.docx')
        collection = chromadb.run()
        return collection 

    def extract_text(self):
        """
        Extract text from the Word document.
        Returns:
        content (dict): Dictionary containing headers and their corresponding text.
        """
        try:
            content = {}
            current_header = None

            for paragraph in self.document.paragraphs:
                if paragraph.style.name.startswith('Heading'):
                    current_header = paragraph.text.strip().lower()
                    content[current_header] = ''
                elif current_header:

                    content[current_header] += paragraph.text.strip() + ' '

            return content
        except Exception as e:
            print(f"Error in Extracting text from word document {self.base_filename}. ", e)


    def extract_bullet_points_hierarchical(cell_text):
        """
        Extract hierarchical bullet points from text.
        Parameters:
            cell_text (str): Text containing bullet points.
        Returns:
            bullets_dict (dict): Dictionary of bullet points and their subpoints.
        """
        try:
            bullets_dict = {}
            lines = cell_text.split("\n")
            current_key = ""
            current_subpoints = []

            for line in lines:
                if re.match(r"^\s*-\s+", line):  # Main bullet point
                    if current_key:
                        bullets_dict[current_key] = current_subpoints
                    current_key = line.strip().lstrip("-").strip()
                    current_subpoints = []
                elif re.match(r"^\s*\*\s+", line):  # Sub bullet point
                    if current_key:
                        current_subpoints.append(line.strip().lstrip("*").strip())
            if current_key:  # Handle the last bullet point
                bullets_dict[current_key] = current_subpoints
            return bullets_dict
        except Exception as e:
            print("Error in extract_bullet_points_hierarchical function in word extraction. ", e)

    def extract_table_with_bullets(self):
        """
        Extract tables with bullet points from the Word document.
        Returns:
        tables_data (list): List of tables with bullet points.
        """
        try:
            tables_data = []
            for table in self.document.tables:
                headers = [cell.text.strip() for cell in table.rows[0].cells]
                table_data = []
                for row in table.rows[1:]:
                    row_dict = {}
                    for i, cell in enumerate(row.cells):
                        cell_text = cell.text.strip()
                        if re.search(r"^\s*(-|\*)\s+", cell_text, re.MULTILINE):  # Check for bullets
                            row_dict[headers[i]] = self.extract_bullet_points_hierarchical(cell_text)
                        else:
                            row_dict[headers[i]] = cell_text
                    table_data.append(row_dict)
                tables_data.append(table_data)
            
            return tables_data
        except Exception as e:
            print(f"Error in extracting tables with bullet points from word document {self.base_filename}. ", e)

    def get_tables_in_format(self,table):
        """
        Format the extracted tables into a dictionary format.
        Parameters:
            table (list): List of extracted table data.
        Returns:
            formatted_data (dict): Dictionary of formatted table data.
        """
        try:
            formatted_data = {}

            for index, item in enumerate(table[0]):
                for key, value in item.items():
                    if key not in formatted_data:
                        formatted_data[key] = {}
                    formatted_data[key][index] = value

            return formatted_data
        except Exception as e:
            print(f"Error in extracting tables from word document {self.base_filename}. ", e)

    def extract_links_from_docx(self):
        """
        Extract hyperlinks from the Word document.
        Returns:
        links (list): List of extracted hyperlinks.
        """
        try:
            links = []
            
            # Regular expression pattern to extract URLs
            url_pattern = re.compile(r'(https?://\S+)')

            for paragraph in self.document.paragraphs:
                # Extracting URLs using the regex pattern
                if len(paragraph.hyperlinks)>0:
                    for hyperlinks in  paragraph.hyperlinks:
                        matches = url_pattern.findall(hyperlinks.address)   
                matches = url_pattern.findall(paragraph.text)
                links.extend(matches)
            list(set(links))
            return links
        except Exception as e:
            print(f"Error in extracting links from word documents {self.base_filename}. ", e)

    def extract_images_from_docx(self,output_dir):
        """
        Parameters:
            output_dir (str): Directory to save the extracted images.
        Returns:
            images (list): List of paths to the extracted images.
        """
        try:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            images = []
            counter = 0
            for rel in self.document.part.rels.values():
                if "image" in rel.reltype:
                    image_data = rel.target_part.blob
                    
                    img_filename = f"image_{counter}.jpg"
                    with open(os.path.join(output_dir, img_filename), "wb") as f:
                        f.write(image_data)
                    images.append(os.path.join(output_dir, img_filename))
                    counter+=1
            return images
        except Exception as e:
            print(f"Error in extracting images from word document {self.base_filename}. ", e)
    
    def get_image_context(self, folder_path, json_data):
        """
        Generate image context for the extracted images.

        Parameters:
            folder_path (str): Path to the folder containing the images.
            json_data (dict): JSON data containing the extracted text and other information.
        Returns:
            result (dict): JSON data with added image context.
        """
        try:
            image_context = ImageDescription()
            result = image_context.analyze_folder(folder_path, json_data,self.file_type)
            return result
        except Exception as e:
            print(f"Error in generating image context for word file {self.base_filename}. ", e)


    def data_extraction(self,output_dir,json_file_path):
        """
        Perform the data extraction process and save the extracted data to a JSON file.
        Parameters:
            output_dir (str): Directory to save the extracted images.
            json_file_path (str): Path to save the JSON file containing the extracted data.
        """
        try:
            data = {}
            text_data = self.extract_text()
            data["text"] = text_data
            image_data = self.extract_images_from_docx(output_dir)
            data["image"] = image_data
            hyperlinks_data = self.extract_links_from_docx()
            data["hyperlinks"] = hyperlinks_data
            table_data = self.extract_table_with_bullets()
            table_data = self.get_tables_in_format(table_data)
            data["table"] = table_data
            if add_image_context == 'True':
                data = self.get_image_context(self.image_dir,data) 
            with open(json_file_path, 'w') as f:
                json.dump(data,f)
        except Exception as e:
            print(f"Error in data extraction function in word document {self.base_filename}. ", e)

# if __name__ == "__main__":
#     file_path = r"data/raw-data/LAM_Synthetic_data.docx"
#     if os.path.exists(file_path):
#         extraction = DocDataExtraction(file_path)
#         extraction.run()
#     else:
#         print("file path is wrong")